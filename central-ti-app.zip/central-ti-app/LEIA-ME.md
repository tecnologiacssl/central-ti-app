# Central de TI — app de computador (portal completo)

App de Windows que abre o **portal CSSL Central TI inteiro** (Início, chamados,
painel, estoque, computadores, chat, agenda etc.) numa janela própria, sem
barra de endereço. Existe também o app separado **Chat Interno**, só com o chat.

## Atualização

- **O portal** vem do GitHub Pages (`tecnologiacssl/estoque-DG`). Atualizou o
  `index.html` lá → o app mostra a versão nova ao abrir (ou sozinho, se ficou
  aberto perto do relógio: confere a cada 20 min e recarrega quando a janela
  estiver escondida).
- **A "casca" do app** se atualiza pelos *Releases* do repositório
  `tecnologiacssl/central-ti-app` (64 e 32 bits têm canais separados).

## Instalar

- Windows 64 bits: `Central-de-TI-Setup-1.0.0.exe`
- Windows 32 bits: `Central-de-TI-Setup-1.0.0-32bits.exe`

Não pede senha de administrador. Se aparecer "O Windows protegeu o
computador": **Mais informações → Executar assim mesmo**.

## O que o app faz

- Login salvo; tudo funciona igual ao navegador.
- O **X** esconde a janela; ela continua perto do relógio recebendo avisos de
  chamado novo, mensagens e ligações. Para fechar de vez: botão direito no
  ícone → **Sair**.
- Notificação do Windows para chamado novo (técnicos/admin), mensagem e
  ligação do chat; clicar abre o Painel ou a conversa.
- Bolinha vermelha no ícone com mensagens não lidas do chat.
- Abre junto com o Windows (dá pra desligar no menu do ícone).
- Impressão de relatórios e etiquetas abre dentro do próprio app.
- F5 recarrega; Ctrl + / Ctrl − mudam o tamanho da letra.

## Publicar versão nova da casca

1. Crie (uma vez) o repositório `tecnologiacssl/central-ti-app` e envie esta pasta.
2. Aumente `"version"` no `package.json`, faça commit, crie a tag `v1.0.1` e envie.
3. O GitHub Actions gera os instaladores 64 e 32 bits e publica o Release.

## Gerar no próprio computador (Windows + Node.js 20)

```
npm install
npm run build      (64 bits)
npm run build32    (32 bits)
```
