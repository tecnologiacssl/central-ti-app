// =====================================================================
// Central de TI — app de computador (Electron) com o portal inteiro
//
// O app NÃO guarda o portal dentro dele: ele abre o portal que está no
// GitHub Pages (repositório tecnologiacssl/estoque-DG), igual ao navegador,
// só que numa janela própria. Por isso, toda vez que o index.html do
// repositório for atualizado, o app já mostra a versão nova — ninguém
// precisa baixar nada de novo.
//
// A "casca" (este arquivo) só muda se mudar o próprio app (ícone, nome,
// comportamento da janela). Aí ela se atualiza sozinha pelos Releases do
// GitHub (electron-updater) — ver LEIA-ME.md.
// =====================================================================
const { app, BrowserWindow, Tray, Menu, nativeImage, shell, session, ipcMain, Notification, net } = require('electron');
const path = require('path');
const fs = require('fs');

const URL_SITE = process.env.CSSL_URL_TESTE || 'https://tecnologiacssl.github.io/estoque-DG/'; // a variável só existe em teste
const URL_CHAT = URL_SITE; // portal inteiro (o app "Chat Interno" usa ?app=chat)
const ORIGEM = URL_SITE.startsWith('file:') ? 'file://' : new URL(URL_SITE).origin;
const APP_ID = 'br.com.cssl.centralti';

let janela = null;
let tray = null;
let saindo = false;
let naoLidas = 0;
let versaoSite = null;          // ETag/Last-Modified do index.html carregado
let recarregarQuandoEsconder = false;

app.setAppUserModelId(APP_ID); // necessário pras notificações do Windows

// ---------- uma instância só ----------
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => mostrarJanela());
}

// ---------- configurações simples (iniciar com o Windows) ----------
const arqConfig = () => path.join(app.getPath('userData'), 'config.json');
function lerConfig() {
  try { return JSON.parse(fs.readFileSync(arqConfig(), 'utf8')); } catch (e) { return {}; }
}
function salvarConfig(c) {
  try { fs.writeFileSync(arqConfig(), JSON.stringify(c, null, 2)); } catch (e) {}
}
function aplicarInicioAutomatico(ligado) {
  if (process.platform !== 'win32' && process.platform !== 'darwin') return;
  app.setLoginItemSettings({ openAtLogin: !!ligado, args: ['--oculto'] });
}

// ---------- janela ----------
function criarJanela() {
  const iniciarOculto = process.argv.includes('--oculto');
  janela = new BrowserWindow({
    width: 1366,
    height: 860,
    minWidth: 380,
    minHeight: 520,
    title: 'Central de TI',
    icon: path.join(__dirname, 'build', 'icon.png'),
    backgroundColor: '#09090b',
    autoHideMenuBar: true,
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      spellcheck: true,
      backgroundThrottling: false // continua recebendo mensagens/ligações minimizado
    }
  });
  janela.setMenuBarVisibility(false);

  janela.once('ready-to-show', () => { if (!iniciarOculto) janela.show(); });

  // links externos (anexos, WhatsApp etc.) abrem no navegador
  janela.webContents.setWindowOpenHandler(({ url }) => {
    // janelas em branco/blob (imprimir relatório, prévia de anexo) abrem no próprio app
    if (!url || url === 'about:blank' || /^(blob|data):/i.test(url)) {
      return { action: 'allow', overrideBrowserWindowOptions: { autoHideMenuBar: true, backgroundColor: '#ffffff', icon: path.join(__dirname, 'build', 'icon.png') } };
    }
    if (/^https?:/i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  janela.webContents.on('will-navigate', (e, url) => {
    if (url.startsWith('file:')) return;
    if (!url.startsWith(ORIGEM)) { e.preventDefault(); shell.openExternal(url); }
  });

  // sem internet → tela "sem conexão" que tenta de novo sozinha
  janela.webContents.on('did-fail-load', (e, codigo, desc, url, principal) => {
    if (!principal || codigo === -3) return; // -3 = carregamento cancelado (normal)
    janela.loadFile(path.join(__dirname, 'offline.html'));
  });

  // botão direito: copiar/colar/corretor
  janela.webContents.on('context-menu', (e, p) => {
    const itens = [];
    if (p.misspelledWord && p.dictionarySuggestions.length) {
      p.dictionarySuggestions.slice(0, 5).forEach(s => itens.push({ label: s, click: () => janela.webContents.replaceMisspelling(s) }));
      itens.push({ type: 'separator' });
    }
    if (p.linkURL) itens.push({ label: 'Abrir link no navegador', click: () => shell.openExternal(p.linkURL) }, { type: 'separator' });
    if (p.isEditable) itens.push({ role: 'cut', label: 'Recortar' });
    if (p.isEditable || p.selectionText) itens.push({ role: 'copy', label: 'Copiar' });
    if (p.isEditable) itens.push({ role: 'paste', label: 'Colar' }, { type: 'separator' }, { role: 'selectAll', label: 'Selecionar tudo' });
    if (p.mediaType === 'image' && p.srcURL) itens.push({ label: 'Abrir imagem no navegador', click: () => shell.openExternal(p.srcURL) });
    if (itens.length) Menu.buildFromTemplate(itens).popup({ window: janela });
  });

  // o X só esconde (fica perto do relógio recebendo mensagens)
  janela.on('close', (e) => {
    if (!saindo) {
      e.preventDefault();
      janela.hide();
      const cfg = lerConfig();
      if (!cfg.avisouBandeja && Notification.isSupported()) {
        new Notification({
          title: 'A Central de TI continua aberta',
          body: 'Ela fica perto do relógio recebendo avisos de chamados e mensagens. Para sair de vez, clique com o botão direito no ícone e escolha "Sair".',
          icon: path.join(__dirname, 'build', 'icon.png')
        }).show();
        cfg.avisouBandeja = true; salvarConfig(cfg);
      }
    }
  });
  janela.on('hide', () => { if (recarregarQuandoEsconder) recarregarSite(); });
  janela.on('focus', () => janela.flashFrame(false));

  carregarSite();
}

async function carregarSite() {
  try { await session.defaultSession.clearCache(); } catch (e) {} // sempre a versão mais nova do portal
  versaoSite = await consultarVersaoSite();
  janela.loadURL(URL_CHAT);
}
function recarregarSite() {
  recarregarQuandoEsconder = false;
  carregarSite();
}

// ---------- verifica se o portal foi atualizado no repositório ----------
// A cada 20 min olha se o index.html mudou. Se mudou, recarrega na hora
// se a janela estiver escondida; senão, na próxima vez que for escondida
// (pra não atrapalhar quem está digitando ou numa ligação).
function consultarVersaoSite() {
  return new Promise((resolve) => {
    try {
      const req = net.request({ method: 'HEAD', url: URL_SITE + '?v=' + Date.now(), cache: 'no-cache' });
      req.on('response', (res) => {
        const h = res.headers || {};
        const pegar = (k) => { const v = h[k] || h[k.toLowerCase()]; return Array.isArray(v) ? v[0] : v; };
        resolve(pegar('etag') || pegar('last-modified') || null);
      });
      req.on('error', () => resolve(null));
      req.end();
    } catch (e) { resolve(null); }
  });
}
setInterval(async () => {
  if (!janela) return;
  const atual = await consultarVersaoSite();
  if (atual && versaoSite && atual !== versaoSite) {
    if (!janela.isVisible()) recarregarSite();
    else recarregarQuandoEsconder = true;
  }
}, 20 * 60 * 1000);

function mostrarJanela() {
  if (!janela) return;
  if (janela.isMinimized()) janela.restore();
  janela.show();
  janela.focus();
}

// ---------- ícone perto do relógio ----------
function criarTray() {
  tray = new Tray(nativeImage.createFromPath(path.join(__dirname, 'assets', 'tray.png')).resize({ width: 16, height: 16 }));
  tray.setToolTip('Central de TI');
  tray.on('click', () => (janela.isVisible() && janela.isFocused()) ? janela.hide() : mostrarJanela());
  atualizarMenuTray();
}
function atualizarMenuTray() {
  const cfg = lerConfig();
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'Abrir Central de TI', click: mostrarJanela },
    { label: 'Recarregar', click: () => { mostrarJanela(); recarregarSite(); } },
    { type: 'separator' },
    {
      label: 'Abrir junto com o Windows', type: 'checkbox', checked: cfg.iniciarComWindows !== false,
      click: (item) => { const c = lerConfig(); c.iniciarComWindows = item.checked; salvarConfig(c); aplicarInicioAutomatico(item.checked); }
    },
    { type: 'separator' },
    { label: 'Sair', click: () => { saindo = true; app.quit(); } }
  ]));
}
function atualizarIndicadorNaoLidas(total) {
  naoLidas = Math.max(0, parseInt(total, 10) || 0);
  if (tray) {
    const img = naoLidas > 0 ? 'tray-alerta.png' : 'tray.png';
    tray.setImage(nativeImage.createFromPath(path.join(__dirname, 'assets', img)).resize({ width: 16, height: 16 }));
    tray.setToolTip(naoLidas > 0 ? `Central de TI — ${naoLidas} não lida${naoLidas > 1 ? 's' : ''}` : 'Central de TI');
  }
  if (janela && process.platform === 'win32') {
    janela.setOverlayIcon(
      naoLidas > 0 ? nativeImage.createFromPath(path.join(__dirname, 'assets', 'selo.png')) : null,
      naoLidas > 0 ? `${naoLidas} mensagens não lidas` : ''
    );
  }
  if (process.platform === 'darwin') app.setBadgeCount(naoLidas);
}

// ---------- recados que a página manda (preload.js) ----------
ipcMain.on('chat:nao-lidas', (e, total) => atualizarIndicadorNaoLidas(total));
ipcMain.on('chat:nova-mensagem', () => { if (janela && !janela.isFocused()) janela.flashFrame(true); });
ipcMain.on('chat:mostrar', () => mostrarJanela());
ipcMain.on('chat:chamada', () => { mostrarJanela(); if (janela) { janela.setAlwaysOnTop(true); setTimeout(() => janela && janela.setAlwaysOnTop(false), 1500); } });
ipcMain.on('chat:tentar-de-novo', () => recarregarSite());

// ---------- atualização automática da casca ----------
function iniciarAtualizador() {
  if (!app.isPackaged) return;
  try {
    const { autoUpdater } = require('electron-updater');
    autoUpdater.autoInstallOnAppQuit = true;
    autoUpdater.on('error', (err) => console.warn('Atualizador:', err && err.message));
    autoUpdater.on('update-downloaded', () => {
      if (Notification.isSupported()) {
        new Notification({ title: 'Central de TI atualizada', body: 'A nova versão será usada na próxima vez que o app abrir.' }).show();
      }
    });
    autoUpdater.checkForUpdates().catch(() => {});
    setInterval(() => autoUpdater.checkForUpdates().catch(() => {}), 6 * 60 * 60 * 1000);
  } catch (e) { console.warn('Atualizador indisponível:', e.message); }
}

app.whenReady().then(() => {
  // permissões: notificação, microfone (ligação), área de transferência
  const PERMITIDAS = ['notifications', 'media', 'clipboard-read', 'clipboard-sanitized-write', 'fullscreen', 'audioCapture'];
  session.defaultSession.setPermissionRequestHandler((wc, permissao, cb) => cb(PERMITIDAS.includes(permissao)));
  session.defaultSession.setPermissionCheckHandler((wc, permissao) => PERMITIDAS.includes(permissao));

  const cfg = lerConfig();
  if (cfg.iniciarComWindows === undefined) { cfg.iniciarComWindows = true; salvarConfig(cfg); }
  aplicarInicioAutomatico(cfg.iniciarComWindows);

  // menu escondido só pros atalhos (zoom, recarregar, copiar/colar)
  Menu.setApplicationMenu(Menu.buildFromTemplate([
    { label: 'Editar', submenu: [{ role: 'undo' }, { role: 'redo' }, { type: 'separator' }, { role: 'cut' }, { role: 'copy' }, { role: 'paste' }, { role: 'selectAll' }] },
    { label: 'Exibir', submenu: [{ label: 'Recarregar', accelerator: 'F5', click: () => recarregarSite() }, { role: 'zoomIn', accelerator: 'CommandOrControl+=' }, { role: 'zoomOut' }, { role: 'resetZoom' }, { role: 'toggleDevTools', accelerator: 'F12' }] }
  ]));

  criarJanela();
  criarTray();
  iniciarAtualizador();
});

app.on('before-quit', () => { saindo = true; });
app.on('window-all-closed', () => { /* continua perto do relógio */ });
app.on('activate', () => mostrarJanela());
